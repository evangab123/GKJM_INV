Projek 
Magang Gereja Kristen Jawa Mergangsan 
