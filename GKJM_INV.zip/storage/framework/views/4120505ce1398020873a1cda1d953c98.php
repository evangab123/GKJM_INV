<?php $__env->startSection('title', 'Daftar Roles | Inventaris GKJM'); ?>

<?php $__env->startSection('main-content'); ?>

    <div class="container-fluid">
        <?php if(session('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>

        <div class="card shadow mb-4">
            <div class="card-header pt-3 d-flex justify-content-between">
                <div class="d-flex align-items-center">
                    
                    <form action="<?php echo e(route('role.index')); ?>" method="GET" class="form-inline">
                        <input type="text" name="search" class="form-control" placeholder="<?php echo e(__('Cari Role ...')); ?>"
                            value="<?php echo e(request('search')); ?>" style="max-width: 200px;">

                        <select name="permission" class="form-control ml-2">
                            <option value=""><?php echo e(__('Filter Permission')); ?></option>
                            <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($perm->name); ?>" <?php echo e(request('permission') == $perm->name ? 'selected' : ''); ?>>
                                    <?php echo e($perm->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <button type="submit" class="btn btn-primary ml-2"><?php echo e(__('Cari')); ?></button>
                        <a href="<?php echo e(route('role.index')); ?>" class="btn btn-secondary ml-2">
                            <i class="fa-solid fa-arrows-rotate"></i> <?php echo e(__('Refresh')); ?>

                        </a>
                    </form>
                </div>
                <a href="<?php echo e(route('role.create')); ?>" class="btn btn-success">
                    <i class="fa-solid fa-plus"></i> <?php echo e(__('Buat Role!')); ?>

                </a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col"><?php echo e(__('No')); ?></th>
                                <th scope="col"><?php echo e(__('Nama')); ?></th>
                                <th scope="col"><?php echo e(__('Hak')); ?></th>
                                <th scope="col"><?php echo e(__('Aksi')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $Roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td scope="row"><?php echo e(($Roles->currentPage() - 1) * $Roles->perPage() + $loop->iteration); ?></td>
                                    <td><?php echo e($Role->name); ?></td>
                                    <td>
                                        <?php if($Role->permissions->count()): ?>
                                            <ul>
                                                <?php $__currentLoopData = $Role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($permission->name); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php else: ?>
                                            <span class="text-muted"><?php echo e(__('Tidak ada hak')); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="width: 200px">
                                        <div class="d-flex">
                                            <a href="<?php echo e(route('role.edit', $Role->id)); ?>" title="Edit"
                                                class="btn  btn-warning mr-2">
                                                <i class="fa-solid fa-pen-to-square"></i> <?php echo e(__(' Edit')); ?>

                                            </a>
                                            <form action="<?php echo e(route('role.destroy', $Role->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button type="submit" class="btn  btn-danger" title="Hapus"
                                                    onclick="return confirm('Anda yakin ingin menghapus hak ini dari role tersebut?')">
                                                    <i class="fas fa-trash"></i> <?php echo e(__(' Hapus!')); ?>

                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Pagination and Info -->
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div class="show-info">
                <?php echo e(__('Melihat')); ?> <?php echo e($Roles->firstItem()); ?> <?php echo e(__('hingga')); ?> <?php echo e($Roles->lastItem()); ?>

                <?php echo e(__('dari total')); ?> <?php echo e($Roles->total()); ?> <?php echo e(__('Roles')); ?>

            </div>
            <div class="pagination">
                <?php echo e($Roles->links()); ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('notif'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('warning')): ?>
        <div class="alert alert-warning border-left-warning alert-dismissible fade show" role="alert">
            <?php echo e(session('warning')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\GKJM_INV\resources\views/role/list.blade.php ENDPATH**/ ?>