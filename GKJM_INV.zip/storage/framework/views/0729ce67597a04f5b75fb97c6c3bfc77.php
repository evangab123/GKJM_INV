<?php $__env->startSection('title', 'Daftar Pengadaan Barang | Inventaris GKJM'); ?>

<?php $__env->startSection('main-content'); ?>
    <?php
        use App\Helpers\PermissionHelper;
        $hasCreate = PermissionHelper::AnyCanCreatePengadaan();
        $hasEdit = PermissionHelper::AnyCanEditPengadaan();
        $hasAccess = PermissionHelper::AnyCanAccessPengadaan();
        $hasDelete = PermissionHelper::AnyCanDeletePengadaan();
    ?>
    <div class="container-fluid">
        <?php if(session('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
        <div class="card shadow mb-4">
            <div class="card-header pt-3 d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center">
                    
                    <form action="<?php echo e(route('pengadaan.index')); ?>" method="GET" class="form-inline">
                        <input type="text" name="search" class="form-control" placeholder="<?php echo e(__('Cari ...')); ?>"
                            value="<?php echo e(request('search')); ?>" style="max-width: 200px;">
                        <button type="submit" class="btn btn-primary ml-2"><?php echo e(__('Cari')); ?></button>
                        <a href="<?php echo e(route('pengadaan.index')); ?>" class="btn btn-secondary ml-2">
                            <i class="fa-solid fa-arrows-rotate"></i> <?php echo e(__('Refresh')); ?>

                        </a>
                    </form>
                </div>
                <?php if($hasCreate['buat']): ?>
                    <a href="#" class="btn btn-success" data-toggle="modal" data-target="#modalPengadaan">
                        <i class="fa-solid fa-plus"></i> <?php echo e(__('Buat Pengadaan Barang!')); ?>

                    </a>
                <?php endif; ?>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col"><?php echo e(__('No')); ?></th>
                                <th scope="col"><?php echo e(__('Merek Barang')); ?></th>
                                <th scope="col"><?php echo e(__('Jumlah')); ?></th>
                                <th scope="col"><?php echo e(__('Referensi')); ?></th>
                                <th scope="col"><?php echo e(__('Keterangan')); ?></th>
                                <th scope="col"><?php echo e(__('Pengaju')); ?></th>
                                <th scope="col"><?php echo e(__('Tanggal Pengajuan')); ?></th>
                                <th scope="col"><?php echo e(__('Kode Barang')); ?></th>
                                <th scope="col"><?php echo e(__('Status')); ?></th>
                                <?php if(
                                    $hasDelete['delete'] ||
                                        $hasEdit['edit'] ||
                                        auth()->user()->hasRole(['Super Admin', 'Majelis'])): ?>
                                    <th scope="col"><?php echo e(__('Aksi')); ?></th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pengadaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td scope="row">
                                        <?php echo e(($pengadaan->currentPage() - 1) * $pengadaan->perPage() + $loop->iteration); ?>

                                    </td>
                                    <td><?php echo e($item->merek_barang); ?></td>
                                    <td><?php echo e($item->jumlah); ?></td>
                                    <td style="width:120px">
                                        <div class="d-flex">
                                            <a href="<?php echo e($item->referensi); ?>" target="_blank" class="btn btn-link">
                                                <?php echo e(__('Lihat Referensi')); ?>

                                            </a>
                                        </div>
                                    </td>
                                    <td><?php echo e($item->keterangan); ?></td>
                                    <td><?php echo e($item->pengguna->nama_pengguna); ?></td>
                                    <td><?php echo e($item->tanggal_pengajuan); ?></td>
                                    <td><?php echo e($item->kode_barang ?? 'Belum dibuat kode barang'); ?></td>
                                    <td>
                                        <?php if($item->status_pengajuan == 'Diajukan'): ?>
                                            <span style="color: blue;">
                                                <i class="fas fa-paper-plane"></i> <?php echo e(__('Diajukan')); ?>

                                            </span>
                                        <?php elseif($item->status_pengajuan == 'Disetujui'): ?>
                                            <span style="color: green;">
                                                <i class="fas fa-check-circle"></i> <?php echo e(__('Disetujui')); ?>

                                            </span>
                                        <?php elseif($item->status_pengajuan == 'Ditolak'): ?>
                                            <span style="color: red;">
                                                <i class="fas fa-times-circle"></i> <?php echo e(__('Ditolak')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <?php if(
                                        $hasDelete['delete'] ||
                                            $hasEdit['edit'] ||
                                            auth()->user()->hasRole(['Super Admin', 'Majelis'])): ?>
                                        <td>
                                            <div class="d-flex flex-column" role="group" aria-label="Tombol Aksi"
                                                style="width: 100%; gap: 5px;">
                                                <?php if(auth()->user()->hasRole(['Super Admin', 'Majelis'])): ?>
                                                    <?php if(!($item->status_pengajuan == 'Disetujui')): ?>
                                                        <!-- Tombol Setuju -->
                                                        <form
                                                            action="<?php echo e(route('pengadaan.approve', $item->pengadaan_id)); ?>"
                                                            method="POST" class="flex-fill" style="margin: 0;">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PUT'); ?>
                                                            <button type="submit" class="btn btn-success"
                                                                onclick="return confirm('<?php echo e(__('Apakah Anda yakin ingin menyetujui pengadaan ini?')); ?>')"
                                                                style="width: 100%; height: 40px;"
                                                                <?php if($item->kode_barang !== null): ?> disabled <?php endif; ?>>
                                                                <i class="fas fa-check"></i> <?php echo e(__('Setuju')); ?>

                                                            </button>
                                                        </form>
                                                        <!-- Tombol Tolak -->
                                                        <form action="<?php echo e(route('pengadaan.reject', $item->pengadaan_id)); ?>"
                                                            method="POST" class="flex-fill" style="margin: 0;">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PUT'); ?>
                                                            <button type="submit" class="btn btn-warning"
                                                                onclick="return confirm('<?php echo e(__('Apakah Anda yakin ingin menolak pengadaan ini?')); ?>')"
                                                                style="width: 100%; height: 40px;"
                                                                <?php if($item->kode_barang !== null): ?> disabled <?php endif; ?>>
                                                                <i class="fas fa-times"></i> <?php echo e(__('Tolak')); ?>

                                                            </button>
                                                        </form>
                                                    <?php elseif($item->status_pengajuan == 'Disetujui'): ?>
                                                        <!-- Tombol Buat Barang -->
                                                        <form
                                                            action="<?php echo e(route('pengadaan.buatbarang', $item->pengadaan_id)); ?>"
                                                            method="POST" class="flex-fill" style="margin: 0;">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('PUT'); ?>
                                                            <button type="submit" class="btn btn-success"
                                                                style="width: 100%; height: 40px;"
                                                                <?php if($item->kode_barang !== null || !auth()->user()->hasRole('Super Admin')): ?> disabled <?php endif; ?>>
                                                                <i class="fas fa-plus"></i> <?php echo e(__('Barang')); ?>

                                                            </button>
                                                        </form>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <?php if($hasEdit['edit']): ?>
                                                    <!-- Tombol Edit -->
                                                    <button class="btn btn-primary flex-fill"
                                                        onclick="openEditModal(<?php echo e($item->pengadaan_id); ?>, '<?php echo e($item->merek_barang); ?>', <?php echo e($item->jumlah); ?>, '<?php echo e($item->referensi); ?>', '<?php echo e($item->keterangan); ?>')"
                                                        style="width: 100%; height: 40px;"
                                                        <?php if($item->status_pengajuan == 'Disetujui'): ?> disabled <?php endif; ?>>
                                                        <i class="fas fa-edit"></i> <?php echo e(__('Edit')); ?>

                                                    </button>
                                                <?php endif; ?>

                                                <?php if($hasDelete['delete']): ?>
                                                    <!-- Tombol Hapus -->
                                                    <form action="<?php echo e(route('pengadaan.destroy', $item->pengadaan_id)); ?>"
                                                        method="post" class="flex-fill" style="margin: 0;">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('delete'); ?>
                                                        <button type="submit" class="btn btn-danger"
                                                            onclick="return confirm('<?php echo e(__('Apakah Anda yakin ingin menghapus data ini?')); ?>')"
                                                            style="width: 100%; height: 40px;"
                                                            <?php if($item->status_pengajuan == 'Disetujui'): ?> disabled <?php endif; ?>>
                                                            <i class="fas fa-trash"></i> <?php echo e(__('Hapus')); ?>

                                                        </button>
                                                    </form>
                                                <?php endif; ?>

                                            </div>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- Pagination and Info -->
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div class="show-info">
                <?php echo e(__('Melihat')); ?> <?php echo e($pengadaan->firstItem()); ?> <?php echo e(__('hingga')); ?> <?php echo e($pengadaan->lastItem()); ?>

                <?php echo e(__('dari total')); ?> <?php echo e($pengadaan->total()); ?> <?php echo e(__('Pengadaan')); ?>

            </div>
            <div class="pagination">
                <?php echo e($pengadaan->links()); ?>

            </div>
        </div>
    </div>
    <!-- Modal Pengadaan Barang -->
    <div class="modal fade" id="modalPengadaan" tabindex="-1" role="dialog" aria-labelledby="modalPengadaanLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalPengadaanLabel"><?php echo e(__('Buat Pengadaan Barang')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Form Pengadaan Barang -->
                    <form action="<?php echo e(route('pengadaan.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="merek_barang"><?php echo e(__('Merek Barang')); ?></label>
                            <input type="text" name="merek_barang" class="form-control" required
                                placeholder="Masukkan Nama Barang" id="merek_barang">
                        </div>
                        <div class="form-group">
                            <label for="jumlah"><?php echo e(__('Jumlah')); ?></label>
                            <input type="number" name="jumlah" class="form-control" required min="1"
                                placeholder="Masukkan Jumlah Barang" id="jumlah">
                        </div>
                        <div class="form-group">
                            <label for="referensi"><?php echo e(__('Referensi Barang')); ?></label>
                            <input type="url" name="referensi" id="referensi" class="form-control" required
                                placeholder="Masukkan URL referensi">
                            <small class="form-text text-muted">
                                <?php echo e(__('Silakan masukkan link yang valid (misalnya, https://contoh.com)')); ?>

                            </small>
                        </div>

                        <div class="form-group">
                            <label for="keterangan"><?php echo e(__('Keterangan')); ?></label>
                            <input type="text" name="keterangan" id="keterangan" class="form-control" required
                                placeholder="Masukkan Keteragan barang" id="keterangan">
                            <small class="form-text text-muted">
                                <?php echo e(__(' Keterangan dari Barang (misalnya, Laptop Ram 12 GB, Windows 11)')); ?>

                            </small>
                        </div>
                        <button type="submit" class="btn btn-primary"><?php echo e(__('Simpan Pengadaan')); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal Edit Pengadaan Barang -->
    <div class="modal fade" id="modalEditPengadaan" tabindex="-1" role="dialog"
        aria-labelledby="modalEditPengadaanLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalEditPengadaanLabel"><?php echo e(__('Edit Pengadaan Barang')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Form Edit Pengadaan Barang -->
                    <form action="" method="POST" id="formEditPengadaan">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <label for="edit_merek_barang"><?php echo e(__('Merek Barang')); ?></label>
                            <input type="text" name="merek_barang" class="form-control" id="edit_merek_barang"
                                required>
                        </div>
                        <div class="form-group">
                            <label for="edit_jumlah"><?php echo e(__('Jumlah')); ?></label>
                            <input type="number" name="jumlah" class="form-control" id="edit_jumlah" required>
                        </div>
                        <div class="form-group">
                            <label for="edit_referensi"><?php echo e(__('Referensi Barang')); ?></label>
                            <input type="url" name="referensi" class="form-control" id="edit_referensi" required>
                            <small class="form-text text-muted">
                                <?php echo e(__('Silakan masukkan link yang valid (misalnya, https://contoh.com)')); ?>

                            </small>
                        </div>
                        <div class="form-group">
                            <label for="edit_keterangan"><?php echo e(__('Keterangan')); ?></label>
                            <input type="text" name="keterangan" class="form-control" id="edit_keterangan" required>
                            <small class="form-text text-muted">
                                <?php echo e(__(' Keterangan dari Barang (misalnya, Laptop Ram 12 GB, Windows 11)')); ?>

                            </small>
                        </div>
                        <button type="submit" class="btn btn-primary"><?php echo e(__('Simpan Pengadaan')); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startPush('notif'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('warning')): ?>
        <div class="alert alert-warning border-left-warning alert-dismissible fade show" role="alert">
            <?php echo e(session('warning')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<script>
    function openEditModal(id, nama, jumlah, referensi, keterangan) {
        // Mengisi data ke dalam modal
        document.getElementById('modalEditPengadaanLabel').textContent = 'Edit Pengadaan Barang ID: ' + id;
        document.getElementById('formEditPengadaan').action = '/pengadaan/' + id; // Update action form
        document.getElementById('edit_merek_barang').value = nama; // Isi merek_barang di form
        document.getElementById('edit_jumlah').value = jumlah; // Isi jumlah di form
        document.getElementById('edit_referensi').value = referensi; // Isi referensi di form
        document.getElementById('edit_keterangan').value = keterangan; // Isi keterangan di form

        // Menampilkan modal
        var modal = new bootstrap.Modal(document.getElementById('modalEditPengadaan'));
        modal.show();
    }
</script>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\GKJM_INV\resources\views/pengadaan/list.blade.php ENDPATH**/ ?>