<?php $__env->startSection('title', 'Edit Pengguna | Inventaris GKJM'); ?>
<?php $__env->startSection('main-content'); ?>
    

    <!-- Main Content goes here -->

    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('pengguna.update', $user->pengguna_id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <input id= 'pengguna_id' type="hidden" name="pengguna_id" value="<?php echo e($user->pengguna_id); ?>">
                <div class="form-group">
                    <label for="nama_pengguna">Nama Lengkap</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['nama_pengguna'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="nama_pengguna" id="nama_pengguna" placeholder="Nama Lengkap" autocomplete="off"
                        value="<?php echo e(old('nama_pengguna') ?? $user->nama_pengguna); ?>">
                    <?php $__errorArgs = ['nama_pengguna'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="jabatan">Jabatan</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['jabatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jabatan"
                        id="jabatan" placeholder="Jabatan" autocomplete="off"
                        value="<?php echo e(old('jabatan') ?? $user->jabatan); ?>">
                    <?php $__errorArgs = ['jabatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="username"
                        id="username" placeholder="Username..." autocomplete="off" value="<?php echo e(old('username')?? $user->username); ?>">
                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                        id="email" placeholder="Email" autocomplete="off" value="<?php echo e(old('email') ?? $user->email); ?>">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                        id="password" placeholder="Password, Boleh Kosong..." autocomplete="off">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="password_confirmation">Confirm Password</label>
                    <input type="password" class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="password_confirmation" id="password_confirmation" placeholder="Confirm Password"
                        autocomplete="off">
                    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


                <div class="form-group">
                    <label for="role_id">Role</label>
                    <select class="form-control <?php $__errorArgs = ['role_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="role_id" id="role_id"
                        onchange="haklist()">
                        <option value="" disabled>Pilih Role Pengguna</option>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role->id); ?>"
                                <?php echo e(old('role_id') == $role->id || (isset($user) && $user->hasRole($role->name)) ? 'selected' : ''); ?>>
                                <?php echo e($role->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['role_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Permissions List -->
                <div id="permissions-container" style="display: none;">
                    <h5>Permissions</h5>
                    <div id="permissions-list"></div>
                </div>

                <button type="submit" class="btn btn-primary">Save</button>
                <a href="<?php echo e(route('pengguna.index')); ?>" class="btn btn-default">Kembali ke list</a>

            </form>
        </div>
    </div>

    <!-- End of Main Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('notif'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('warning')): ?>
        <div class="alert alert-warning border-left-warning alert-dismissible fade show" role="alert">
            <?php echo e(session('warning')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        haklist(); // Call the function to populate permissions on page load
    });

    function haklist() {
        const roleId = document.getElementById('role_id').value;
        const penggunaid = document.getElementById('pengguna_id').value; // Assume you have a user ID field
        const permissionsContainer = document.getElementById('permissions-container');

        // Clear previous content
        permissionsContainer.innerHTML = '';

        // Check if user exists
        if (penggunaid || roleId) {
            permissionsContainer.style.display = 'block';

            // Fetch permissions from the role and user
            fetch(
                `/pengguna/${penggunaid}/edit/permissions?roleId=${roleId}`) // Adjust the endpoint to send both roleId and penggunaid

                .then(response => response.json())
                .then(data => {
                    // Check if permissions are found for the role or user
                    if (data.permissions.length > 0) {
                        // Create a heading for the permissions list
                        const heading = document.createElement('h6');
                        heading.classList.add('font-weight-bold', 'mb-3');
                        heading.textContent = 'Daftar Hak Akses untuk Pengguna Ini:';
                        permissionsContainer.appendChild(heading);

                        // Create a list for permissions
                        const listGroup = document.createElement('div');
                        listGroup.classList.add('list-group');

                        // Store user's existing permissions in an array for easy checking
                        const userPermissions = data.userPermissions.map(permission => permission.name);

                        // Iterate over the role's permissions and create checkboxes
                        data.permissions.forEach(permission => {
                            const checkboxContainer = document.createElement('div');
                            checkboxContainer.classList.add('form-check', 'mb-2'); // Add margin-bottom here

                            // Check if the permission exists in the user's current permissions and check the box if true
                            const isChecked = userPermissions.includes(permission.name) ? 'checked' : '';

                            checkboxContainer.innerHTML = `
                            <input class="form-check-input"
                                   type="checkbox"
                                   name="permissions[]"
                                   value="${permission.name}"
                                   id="permission-${permission.id}"
                                   ${isChecked}>
                            <label class="form-check-label" for="permission-${permission.id}">
                                ${permission.name}
                            </label>
                        `;

                            listGroup.appendChild(checkboxContainer);
                        });

                        permissionsContainer.appendChild(listGroup);
                    } else {
                        // Display a message if no permissions are found
                        const noPermissionsMessage = document.createElement('p');
                        noPermissionsMessage.classList.add('text-muted');
                        noPermissionsMessage.textContent = 'Tidak ada hak akses untuk pengguna atau role ini.';
                        permissionsContainer.appendChild(noPermissionsMessage);
                    }
                })
                .catch(error => {
                    console.error('Error fetching permissions:', error);
                    const errorMessage = document.createElement('p');
                    errorMessage.classList.add('text-danger');
                    errorMessage.textContent = 'Terjadi kesalahan saat mengambil hak akses.';
                    permissionsContainer.appendChild(errorMessage);
                });
        } else {
            // Optionally clear the permissions list if no user or role is selected
            const noUserMessage = document.createElement('p');
            noUserMessage.classList.add('text-muted');
            noUserMessage.textContent = 'Silakan pilih pengguna dan role untuk melihat hak akses.';
            permissionsContainer.appendChild(noUserMessage);
        }
    }
</script>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\GKJM_INV\resources\views/pengguna/edit.blade.php ENDPATH**/ ?>