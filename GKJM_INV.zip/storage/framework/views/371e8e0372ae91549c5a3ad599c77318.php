<?php $__env->startSection('title', 'Edit Pengguna | Inventaris GKJM'); ?>

<?php $__env->startSection('main-content'); ?>

<div class="card">
    <div class="card-body">
        <form action="<?php echo e(route('pengguna.update', $user->pengguna_id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <input id='pengguna_id' type="hidden" name="pengguna_id" value="<?php echo e($user->pengguna_id); ?>">

            <div class="form-group">
                <label for="nama_pengguna"><?php echo e(__('Nama Lengkap')); ?></label>
                <input type="text" class="form-control <?php $__errorArgs = ['nama_pengguna'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama_pengguna" id="nama_pengguna" placeholder="Nama Lengkap" autocomplete="off" value="<?php echo e(old('nama_pengguna') ?? $user->nama_pengguna); ?>">
                <?php $__errorArgs = ['nama_pengguna'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="jabatan"><?php echo e(__('Jabatan')); ?></label>
                <input type="text" class="form-control <?php $__errorArgs = ['jabatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jabatan" id="jabatan" placeholder="Jabatan" autocomplete="off" value="<?php echo e(old('jabatan') ?? $user->jabatan); ?>">
                <?php $__errorArgs = ['jabatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="username"><?php echo e(__('Username')); ?></label>
                <input type="text" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="username" id="username" placeholder="Username..." autocomplete="off" value="<?php echo e(old('username')?? $user->username); ?>">
                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="email"><?php echo e(__('Email')); ?></label>
                <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" id="email" placeholder="Email" autocomplete="off" value="<?php echo e(old('email') ?? $user->email); ?>">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="password"><?php echo e(__('Password')); ?></label>
                <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" id="password" placeholder="Password, Boleh Kosong..." autocomplete="off">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="password_confirmation"><?php echo e(__('Password Konfirmasi')); ?></label>
                <input type="password" class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password_confirmation" id="password_confirmation" placeholder="Confirm Password" autocomplete="off">
                <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="role_id"><?php echo e(__('Role')); ?></label>
                <select class="form-control <?php $__errorArgs = ['role_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="role_id" id="role_id" onchange="haklist()">
                    <option value="" disabled><?php echo e(__('Pilih Role Pengguna')); ?></option>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($role->id); ?>" <?php echo e(old('role_id') == $role->id || (isset($user) && $user->hasRole($role->name)) ? 'selected' : ''); ?>>
                            <?php echo e($role->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['role_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Permissions List -->
            <div id="permissions-container" style="display: none;">
                <h5><?php echo e(__('Permissions')); ?></h5>
                <div id="permissions-list"></div>
            </div>

            <button type="submit" class="btn btn-primary">Save</button>
            <a href="<?php echo e(route('pengguna.index')); ?>" class="btn btn-default"><?php echo e(__('kembali')); ?></a>

        </form>
    </div>
</div>

<!-- End of Main Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('notif'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('warning')): ?>
        <div class="alert alert-warning border-left-warning alert-dismissible fade show" role="alert">
            <?php echo e(session('warning')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        haklist();
    });

    function formatHakAkses(hak) {
        const hakList = hak.split('-');
        const deskripsiMap = {
            'lihat': 'Melihat',
            'perbarui': 'Memperbarui',
            'buat': 'Membuat',
            'hapus': 'Menghapus',
            'peminjam': 'Peminjaman',
            'pengadaan': 'Pengadaan',
            'r.': 'Ruangan',
            'semua': 'Semua'
        };

        let hakFormatted = [];
        hakList.forEach((item, index) => {
            if (item === "semua" && index === 0) {
                hakFormatted.push("Melihat, Membuat, Memperbarui, Menghapus");
            } else if (item === "semua" && index === 1) {
                hakFormatted.push("Pengadaan, Peminjaman, Barang, Penghapusan, dan Pemakaian");
            } else if (item === "semua" && index === 2) {
                hakFormatted.push("Semua Ruangan");
            } else {
                hakFormatted.push(deskripsiMap[item] || item.charAt(0).toUpperCase() + item.slice(1));
            }
        });

        return hakFormatted.join(', ');
    }

    function haklist() {
        const roleId = document.getElementById('role_id').value;
        const penggunaid = document.getElementById('pengguna_id').value;
        const permissionsContainer = document.getElementById('permissions-container');

        permissionsContainer.innerHTML = '';

        if (penggunaid || roleId) {
            permissionsContainer.style.display = 'block';
            const url = `<?php echo e(route('pengguna.permissions.edit', ['pengguna' => '__pengguna_id__'])); ?>`
                .replace('__pengguna_id__', penggunaid) + `?roleId=${roleId}`;

            fetch(url)
                .then(response => response.json())
                .then(data => {
                    if (data.permissions.length > 0) {
                        const heading = document.createElement('h6');
                        heading.classList.add('font-weight-bold', 'mb-3');
                        heading.textContent = 'Daftar Hak Akses untuk Pengguna Ini:';
                        permissionsContainer.appendChild(heading);

                        const listGroup = document.createElement('div');
                        listGroup.classList.add('list-group');

                        const userPermissions = data.userPermissions.map(permission => permission.name);

                        data.permissions.forEach(permission => {
                            const checkboxContainer = document.createElement('div');
                            checkboxContainer.classList.add('form-check', 'mb-2');

                            const isChecked = userPermissions.includes(permission.name) ? 'checked' : '';

                            checkboxContainer.innerHTML = `
                            <input class="form-check-input"
                                   type="checkbox"
                                   name="permissions[]"
                                   value="${permission.name}"
                                   id="permission-${permission.id}"
                                   ${isChecked}>
                            <label class="form-check-label" for="permission-${permission.id}">
                                ${formatHakAkses(permission.name)}
                            </label>
                        `;

                            listGroup.appendChild(checkboxContainer);
                        });

                        permissionsContainer.appendChild(listGroup);
                    } else {
                        const noPermissionsMessage = document.createElement('p');
                        noPermissionsMessage.classList.add('text-muted');
                        noPermissionsMessage.textContent = 'Tidak ada hak akses untuk pengguna atau role ini.';
                        permissionsContainer.appendChild(noPermissionsMessage);
                    }
                })
                .catch(error => {
                    console.error('Error fetching permissions:', error);
                    const errorMessage = document.createElement('p');
                    errorMessage.classList.add('text-danger');
                    errorMessage.textContent = 'Terjadi kesalahan saat mengambil hak akses.';
                    permissionsContainer.appendChild(errorMessage);
                });
        } else {
            // Optionally clear the permissions list if no user or role is selected
            const noUserMessage = document.createElement('p');
            noUserMessage.classList.add('text-muted');
            noUserMessage.textContent = 'Silakan pilih pengguna dan role untuk melihat hak akses.';
            permissionsContainer.appendChild(noUserMessage);
        }
    }
</script>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\GKJM_INV\resources\views/pengguna/edit.blade.php ENDPATH**/ ?>