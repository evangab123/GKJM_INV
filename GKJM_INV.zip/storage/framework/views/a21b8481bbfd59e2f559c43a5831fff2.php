<?php $__env->startSection('title', 'Tambah Barang | Inventaris GKJM'); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="row mb-3">
        <div class="d-flex">
            <a href="<?php echo e(route('barang.index')); ?>" class="btn btn-secondary">
                <i class="fa-solid fa-arrow-left"></i> <?php echo e(__('Kembali')); ?>

            </a>
        </div>
    </div>
    <?php if(session('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title"><?php echo e(__('Tambah Barang')); ?></h5>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('barang.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="merek_barang"><?php echo e(__('Merek Barang')); ?></label>
                            <input type="text" class="form-control" id="merek_barang" name="merek_barang"
                            value="<?php echo e(old('harga_pembelian', $pengadaan->merek_barang ?? '')); ?>">
                        </div>
                        <!-- Hidden input untuk mengirimkan status fromApprove jika tersedia -->
                        <?php if(isset($fromApprove)): ?>
                            <input type="hidden" name="from" value="<?php echo e($fromApprove ? 'approve' : ''); ?>">
                        <?php endif; ?>
                        <!-- Hidden input untuk mengirimkan ID pengadaan jika tersedia -->
                        <?php if(isset($idp)): ?>
                            <input type="hidden" name="idp" value="<?php echo e($idp); ?>">
                        <?php endif; ?>

                        <div class="form-group">
                            <label for="perolehan_barang"><?php echo e(__('Perolehan')); ?></label>
                            <select class="form-control" id="perolehan_barang" name="perolehan_barang">
                                <option value="Persembahan"><?php echo e(__('Persembahan')); ?></option>
                                <option value="Pembelian"><?php echo e(__('Pembelian')); ?></option>
                                <option value="Pembuatan"><?php echo e(__('Pembuatan')); ?></option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="harga_pembelian"><?php echo e(__('Harga Beli')); ?></label>
                            <input type="number" class="form-control" id="harga_pembelian" name="harga_pembelian"
                                onchange="calculateNilaiEkonomis()">
                        </div>
                        <div class="form-group">
                            <label for="tahun_pembelian"><?php echo e(__('Tahun Beli')); ?></label>
                            <input type="text" class="form-control" id="tahun_pembelian" name="tahun_pembelian"
                                onchange="calculateNilaiEkonomis()">
                        </div>

                        <div class="form-group">
                            <label for="nilai_ekonomis_barang"><?php echo e(__('Nilai Ekonomis')); ?></label>
                            <input type="number" class="form-control" id="nilai_ekonomis_barang"
                                name="nilai_ekonomis_barang" readonly>
                        </div>
                        <div class="form-group">
                            <label for="jumlah"><?php echo e(__('Jumlah/Stok')); ?></label>
                            <input type="number" class="form-control" id="jumlah" name="jumlah"
                            value="<?php echo e(old('harga_pembelian', $pengadaan->jumlah ?? '')); ?>">
                        </div>
                        <div class="form-group">
                            <label for="keterangan"><?php echo e(__('Keterangan')); ?></label>
                            <input type="text" class="form-control" id="keterangan" name="keterangan"
                                value="<?php echo e(old('harga_pembelian', $pengadaan->keterangan ?? '')); ?>">

                        </div>
                        <div class="form-group">
                            <label for="ruang_id"><?php echo e(__('Ruang')); ?></label>
                            <select class="form-control" name="ruang_id" id="ruang_id">
                                <?php $__currentLoopData = $ruang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rua): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($rua->ruang_id); ?>"><?php echo e($rua->nama_ruang); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="kondisi_id"><?php echo e(__('Kondisi')); ?></label>
                            <select class="form-control" name="kondisi_id" id="kondisi_id">
                                <?php $__currentLoopData = $kondisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kon->kondisi_id); ?>"><?php echo e($kon->deskripsi_kondisi); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="kategori_barang_id"><?php echo e(__('Kategori')); ?></label>
                            <select class="form-control" name="kategori_barang_id" id="kategori_barang_id">
                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kat->kategori_barang_id); ?>"><?php echo e($kat->nama_kategori); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="status_barang"><?php echo e(__('Status')); ?></label>
                            <select class="form-control" name="status_barang" id="status_barang">
                                <option value="Ada"><?php echo e(__('Ada')); ?></option>
                                <option value="Dipinjam"><?php echo e(__('Dipinjam')); ?></option>
                                <option value="Diperbaiki"><?php echo e(__('Diperbaiki')); ?></option>
                                <option value="Dihapus"><?php echo e(__('Dihapus')); ?></option>
                                <option value="Dipakai"><?php echo e(__('Dipakai')); ?></option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="foto_barang"><?php echo e(__('Foto Barang')); ?></label>
                            <input type="file" class="form-control" name="path_gambar" accept="image/*"
                                id="foto_barang">
                        </div>
                        <button type="submit" class="btn btn-success"><?php echo e(__('Tambah Barang')); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('notif'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<script>
    function calculateNilaiEkonomis() {
        const hargaPembelianInput = document.getElementById('harga_pembelian');
        const tahunPembelianInput = document.getElementById('tahun_pembelian');
        const nilaiEkonomisInput = document.getElementById('nilai_ekonomis_barang');

        const hargaPembelian = parseFloat(hargaPembelianInput.value) || 0;
        const tahunPembelian = parseFloat(tahunPembelianInput.value) || new Date().getFullYear();

        const umurEkonomis = 10;
        const nilaiSisa = 100;

        const totalDepreciation = (hargaPembelian - nilaiSisa) / umurEkonomis;

        const currentYear = new Date().getFullYear();
        const yearsUsed = currentYear - tahunPembelian;

        let nilaiEkonomis = hargaPembelian - (totalDepreciation * yearsUsed);
        nilaiEkonomis = nilaiEkonomis >= 0 ? nilaiEkonomis : 0;

        nilaiEkonomisInput.value = nilaiEkonomis.toFixed(2);
    }
</script>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\GKJM_INV\resources\views/barang/create.blade.php ENDPATH**/ ?>