<?php $__env->startSection('title', __('Edit Role dan Permissions | Inventaris GKJM')); ?>

<?php $__env->startSection('main-content'); ?>
    <!-- Main Content -->
    <div class="card">
        <div class="card-body">
            <!-- Form untuk update Role -->
            <form action="<?php echo e(route('role.update', $role->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <!-- Nama Role -->
                <div class="form-group">
                    <label for="nama_role"><?php echo e(__('Nama Role')); ?></label>
                    <input type="text" class="form-control <?php $__errorArgs = ['nama_role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama_role"
                        id="nama_role" value="<?php echo e(old('nama_role', $role->name)); ?>" placeholder="<?php echo e(__('Nama Role...')); ?>"
                        autocomplete="off">
                    <?php $__errorArgs = ['nama_role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Submit button untuk simpan perubahan -->
                <button type="submit" class="btn btn-primary"><?php echo e(__('Simpan Perubahan')); ?></button>
            </form>

            <!-- Daftar Permissions -->
            <div id="permissions-list" class="mt-4 md-4">
                <h5><?php echo e(__('Daftar Hak Akses yang dimiliki Role:')); ?></h5>

                <?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form action="<?php echo e(route('roles.permissions.destroy', [$role->id, $permission->id])); ?>" method="POST"
                        style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-danger"
                            onclick="return confirm('<?php echo e(__('Apakah kamu yakin ingin menghapus permission ini dari role?')); ?>')">
                            <?php echo e($permission->name); ?> <i class="fas fa-times"></i>
                        </button>
                    </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <h6 class="mt-4 md-4"><?php echo e(__('Petunjuk: Klik Role yang mau dihapus...')); ?></h6>
            </div>

            <!-- Form untuk menambah Permission -->
            <form action="<?php echo e(route('role.givepermissions', $role->id)); ?>" method="POST" class="mt-4">
                <?php echo csrf_field(); ?>

                <!-- Select Permissions -->
                <div class="form-group">
                    <label for="permissions"><?php echo e(__('Tambah Permission')); ?></label>
                    <select name="permissions" id="permissions" class="form-control">
                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($permission->name); ?>">
                                <?php echo e($permission->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <!-- Submit button untuk tambah permission -->
                <button type="submit" class="btn btn-primary"><?php echo e(__('Tambah Hak Akses')); ?></button>
            </form>
        </div>

        <!-- Tombol kembali -->
        <a href="<?php echo e(route('role.index')); ?>" class="btn btn-default"><?php echo e(__('Kembali ke list')); ?></a>
    </div>
    <!-- End of Main Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('notif'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('warning')): ?>
        <div class="alert alert-warning border-left-warning alert-dismissible fade show" role="alert">
            <?php echo e(session('warning')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\GKJM_INV\resources\views/role/edit.blade.php ENDPATH**/ ?>