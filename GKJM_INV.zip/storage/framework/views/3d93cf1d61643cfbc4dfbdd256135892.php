<?php $__env->startSection('title', __('Daftar Pengguna | Inventaris GKJM')); ?>
<?php
    function formatHakAkses($hak)
    {
        $hakList = explode('-', $hak);
        $hakFormatted = [];
        $index = 0;

        $deskripsiMap = [
            'lihat' => 'Melihat',
            'perbarui' => 'Memperbarui',
            'buat' => 'Membuat',
            'hapus' => 'Menghapus',
            'peminjam' => 'Peminjaman',
            'pengadaan' => 'Pengadaan',
            'r.' => 'Ruangan',
            'semua' => 'Semua',
        ];

        foreach ($hakList as $item) {
            if ($item === 'semua' && $index === 0) {
                $hakFormatted[] = 'Melihat, membuat, memperbarui, menghapus';
            } elseif ($item === 'semua' && $index === 1) {
                $hakFormatted[] = 'Pengadaan, Peminjaman, Barang, Penghapusan, dan Pemakaian';
            } elseif ($item === 'semua' && $index === 2) {
                $hakFormatted[] = 'Semua Ruangan';
            } else {
                $hakFormatted[] = $deskripsiMap[$item] ?? ucfirst($item);
            }
            $index += 1;
        }

        if (count($hakFormatted) > 1) {
            $lastElement = array_pop($hakFormatted);
            return implode(', ', $hakFormatted) . ' di ' . $lastElement;
        }
    }
?>
<?php $__env->startSection('main-content'); ?>

    <div class="container-fluid">
        <?php if(session('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
        <div class="card shadow">
            <div class="card-header pt-3 d-flex justify-content-between">
                <div class="d-flex align-items-center">
                    
                    <form action="<?php echo e(route('pengguna.index')); ?>" method="GET" class="form-inline">
                        <input type="text" name="search" class="form-control" placeholder="<?php echo e(__('Cari ...')); ?>"
                            value="<?php echo e(request('search')); ?>" style="max-width: 200px;" oninput="this.form.submit()">
                        <select name="permission" class="form-control ml-2" style="max-width: 200px;" onchange="this.form.submit()">
                            <option value=""><?php echo e(__('Filter Hak')); ?></option>
                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($perm->name); ?>"
                                    <?php echo e(request('permission') == $perm->name ? 'selected' : ''); ?>>
                                    <?php echo e(formatHakAkses($perm->name)); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <select name="roles" class="form-control ml-2" onchange="this.form.submit()">
                            <option value=""><?php echo e(__('Filter Roles')); ?></option>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($role->name); ?>" <?php echo e(request('roles') == $role->name ? 'selected' : ''); ?>>
                                    <?php echo e($role->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <a href="<?php echo e(route('pengguna.index')); ?>" class="btn btn-secondary ml-2">
                            <i class="fa-solid fa-arrows-rotate"></i> <?php echo e(__('Refresh')); ?>

                        </a>
                    </form>
                </div>
                <a href="<?php echo e(route('pengguna.create')); ?>" class="btn btn-success">
                    <i class="fa-solid fa-plus"></i> <?php echo e(__('Buat Pengguna!')); ?></a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col"><?php echo e(__('No')); ?></th>
                                <th scope="col"><?php echo e(__('Nama')); ?></th>
                                <th scope="col"><?php echo e(__('Jabatan')); ?></th>
                                <th scope="col"><?php echo e(__('Email')); ?></th>
                                <th scope="col"><?php echo e(__('Role')); ?></th>
                                <th scope="col"><?php echo e(__('Hak yang dimiliki')); ?></th>
                                <th scope="col"><?php echo e(__('Aksi')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pengguna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td scope="row">
                                        <?php echo e(($pengguna->currentPage() - 1) * $pengguna->perPage() + $loop->iteration); ?></td>
                                    <td><?php echo e($user->nama_pengguna); ?></td>
                                    <td><?php echo e($user->jabatan); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->getRoleNames()->first()); ?></td>
                                    <td>
                                        <?php if($user->permissions->count()): ?>
                                            <ul>
                                                <?php $__currentLoopData = $user->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e(formatHakAkses($permission->name)); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php else: ?>
                                            <span class="text-muted"><?php echo e(__('Tidak ada hak')); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="width:200px">
                                        <div class="d-flex">
                                            <a href="<?php echo e(route('pengguna.edit', $user->pengguna_id)); ?>"
                                                title="<?php echo e(__('Edit')); ?>" class="btn btn-warning mr-2">
                                                <i class="fa-solid fa-pen-to-square"></i> <?php echo e(__('Edit!')); ?>

                                            </a>
                                            <form action="<?php echo e(route('pengguna.destroy', $user->pengguna_id)); ?>"
                                                method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button type="submit" class="btn btn-danger" title="<?php echo e(__('Hapus')); ?>"
                                                    onclick="return confirm('<?php echo e(__('Are you sure to delete this?')); ?>')">
                                                    <i class="fas fa-trash"></i><?php echo e(__('Hapus!')); ?>

                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- Pagination and Info -->
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div class="show-info">
                <?php echo e(__('Melihat')); ?> <?php echo e($pengguna->firstItem()); ?> <?php echo e(__('hingga')); ?> <?php echo e($pengguna->lastItem()); ?>

                <?php echo e(__('dari total')); ?> <?php echo e($pengguna->total()); ?> <?php echo e(__('Pengguna')); ?>

            </div>
            <div class="pagination">
                <?php echo e($pengguna->links()); ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('notif'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('warning')): ?>
        <div class="alert alert-warning border-left-warning alert-dismissible fade show" role="alert">
            <?php echo e(session('warning')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\GKJM_INV\resources\views/pengguna/list.blade.php ENDPATH**/ ?>