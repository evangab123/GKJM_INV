<?php $__env->startSection('title', 'Detail Keterangan Barang | Inventaris GKJM'); ?>

<?php $__env->startSection('main-content'); ?>
    <?php
        use App\Helpers\PermissionHelper;
        $hasCreate = PermissionHelper::AnyCanCreateBarang();
        $hasEdit = PermissionHelper::AnyCanEditBarang();
        $hasAccess = PermissionHelper::AnyHasAccesstoBarang();
        $hasDelete = PermissionHelper::AnyCanDeleteBarang();
    ?>
    <div class="row mb-3">
        <div class="d-flex">
            <a href="javascript:history.back()" class="btn btn-secondary">
                <i class="fa-solid fa-arrow-left"></i> <?php echo e(__('Kembali')); ?>

            </a>
            <!-- Tombol Add Keterangan -->
            <?php if($hasCreate['buat']): ?>
                <button type="button" class="btn btn-success ml-2" data-toggle="modal" data-target="#addKeteranganModal">
                    <i class="fa-solid fa-plus"></i> <?php echo e(__('Tambah Keterangan Baru')); ?>

                </button>
            <?php endif; ?>

        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="addKeteranganModal" tabindex="-1" role="dialog" aria-labelledby="addKeteranganModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addKeteranganModalLabel"><?php echo e(__('Tambah Keterangan Baru')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('keterangan.store', $barang->kode_barang)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="kode_barang" value="<?php echo e($barang->kode_barang); ?>">
                        <div class="form-group">
                            <label for="keterangan"><?php echo e(__('Keterangan')); ?></label>
                            <input id = 'keterangan' type="text" class="form-control" name="keterangan" required>
                        </div>
                        <div class="form-group">
                            <label for="tanggal"><?php echo e(__('Tanggal')); ?></label>
                            <input id = 'tanggal' type="date" class="form-control" name="tanggal" required>
                        </div>
                        <button type="submit" class="btn btn-primary"><?php echo e(__('Tambah Keterangan')); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title"><?php echo e(__('Detail Keterangan untuk Barang ') . $barang->merek_barang); ?>: </h5>

                </div>
                <div class="card-body">
                    <table class="table table-bordered table-striped table-hover">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col"><?php echo e(__('No')); ?></th>
                                <th scope="col"><?php echo e(__('Tanggal')); ?></th>
                                <th scope="col"><?php echo e(__('Keterangan')); ?></th>
                                <?php if($hasDelete['delete']): ?>
                                    <th scope="col"><?php echo e(__('Aksi')); ?></th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $keteranganList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keterangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td scope="row"><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($keterangan->tanggal); ?></td>
                                    <td><?php echo e($keterangan->keterangan); ?></td>
                                    <?php if($hasDelete['delete']): ?>
                                        <td style="width: 200px;">
                                            <form action="<?php echo e(route('keterangan.destroy', $keterangan->keterangan_id)); ?>"
                                                method="POST" style="display:inline;"
                                                onsubmit="return confirm('<?php echo e(__('Apakah Anda yakin ingin menghapus?')); ?>');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>

                                                <?php
                                                    $dateDiff = \Carbon\Carbon::parse($keterangan->tanggal)->diffInDays(
                                                        now(),
                                                    );
                                                ?>

                                                <button type="submit" class="btn btn-danger"
                                                    <?php echo e($dateDiff > (int) env('DELETE_PERIOD_DAYS', 7) ? 'disabled' : ''); ?>>
                                                    <i class="fas fa-trash"></i> <?php echo e(__(' Hapus!')); ?>

                                                </button>

                                            </form>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('notif'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\GKJM_INV\resources\views/barang/detilketerangan.blade.php ENDPATH**/ ?>