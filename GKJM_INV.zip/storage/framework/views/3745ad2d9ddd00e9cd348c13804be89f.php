<?php $__env->startSection('title', __('Buat Hak/Permission | Inventaris GKJM')); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="card">
        <div class="card-body">
            <h2 class="text-info mb-3"><?php echo e(__('Petunjuk: Nama yang disimpan adalah slug')); ?></h2>
            <p class="text-muted mb-4"><?php echo e(__('Silakan masukkan sesuai form. Slug akan otomatis dihasilkan berdasarkan pilihan Anda.')); ?></p>

            <form action="<?php echo e(route('hak.store')); ?>" method="post">
                <?php echo csrf_field(); ?>

                <!-- Select Tindakan -->
                <div class="form-group">
                    <label for="tindakan"><?php echo e(__('Tindakan')); ?></label>
                    <select name="tindakan" id="tindakan" class="form-control" required onchange="generateSlug()">
                        <option value=""><?php echo e(__('Pilih Tindakan...')); ?></option>
                        <option value="buat"><?php echo e(__('Buat')); ?></option>
                        <option value="hapus"><?php echo e(__('Hapus')); ?></option>
                        <option value="perbarui"><?php echo e(__('Perbarui')); ?></option>
                        <option value="lihat"><?php echo e(__('Lihat')); ?></option>
                        <option value="semua"><?php echo e(__('Semua')); ?></option>
                    </select>
                </div>

                <!-- Select Entitas -->
                <div class="form-group">
                    <label for="entitas"><?php echo e(__('Entitas')); ?></label>
                    <select name="entitas" id="entitas" class="form-control" required onchange="generateSlug()">
                        <option value=""><?php echo e(__('Pilih Entitas...')); ?></option>
                        <option value="barang"><?php echo e(__('Barang')); ?></option>
                        <option value="pengadaan"><?php echo e(__('Pengadaan')); ?></option>
                        <option value="penghapusan"><?php echo e(__('Penghapusan')); ?></option>
                        <option value="pemakai"><?php echo e(__('Pemakai')); ?></option>
                        <option value="peminjam"><?php echo e(__('Peminjam')); ?></option>
                        <option value="semua"><?php echo e(__('Semua')); ?></option>
                    </select>
                </div>

                <!-- Select Ruangan -->
                <div class="form-group">
                    <label for="ruangan"><?php echo e(__('Ruang')); ?></label>
                    <select name="ruangan" id="ruangan" class="form-control" required onchange="generateSlug()">
                        <option disabled="true"><?php echo e(__('Pilih Ruang...')); ?></option>
                        <option value="semua" style="color:rgb(214, 22, 22);"><?php echo e(__('Semua Ruangan')); ?></option>
                        <?php $__currentLoopData = $ruangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($ruangan->nama_ruang); ?>"><?php echo e($ruangan->nama_ruang); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <!-- Input Slug Hak -->
                <div class="form-group">
                    <label for="nama_hak_slug"><?php echo e(__('Slug Hak')); ?></label>
                    <input type="text" class="form-control <?php $__errorArgs = ['nama_hak_slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="nama_hak_slug" id="nama_hak_slug" placeholder="slug-hak..." autocomplete="off" readonly required>
                    <?php $__errorArgs = ['nama_hak_slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <button type="submit" class="btn btn-primary"><?php echo e(__('Simpan')); ?></button>
                <a href="<?php echo e(route('hak.index')); ?>" class="btn btn-default"><?php echo e(__('Kembali ke list')); ?></a>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<script>
    function generateSlug() {
        const tindakan = document.querySelector('#tindakan').value;
        const entitas = document.querySelector('#entitas').value;
        const ruangan = document.querySelector('#ruangan').value;

        // Membuat slug dari pilihan
        const slugTindakan = tindakan ? tindakan.toLowerCase() : '';
        const slugEntitas = entitas ? entitas.toLowerCase() : '';
        const slugRuang = ruangan ? ruangan.toLowerCase() : '';

        // Menggabungkan semua slug
        const finalSlug = [slugTindakan, slugEntitas, slugRuang].filter(Boolean).join('-');

        // Memperbarui nilai input slug
        document.querySelector('#nama_hak_slug').value = finalSlug;
    }
</script>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\GKJM_INV\resources\views/hak/create.blade.php ENDPATH**/ ?>