<?php $__env->startSection('title', __('Daftar Barang | Inventaris GKJM')); ?>

<?php $__env->startSection('main-content'); ?>
    <?php
        use App\Helpers\PermissionHelper;
        $hasCreate = PermissionHelper::AnyCanCreateBarang();
        $hasEdit = PermissionHelper::AnyCanEditBarang();
        $hasAccess = PermissionHelper::AnyHasAccesstoBarang();
        $hasDelete = PermissionHelper::AnyCanDeleteBarang();
    ?>
    <!-- Main Content goes here -->
    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center">
                    
                    <form action="<?php echo e(route('barang.index')); ?>" method="GET" class="form-inline">
                        <input type="text" name="search" class="form-control" placeholder="<?php echo e(__('Cari ...')); ?>"
                            value="<?php echo e(request('search')); ?>" style="max-width: 200px;" oninput="this.form.submit()">
                        <a href="#" class="btn btn-info mx-2" data-toggle="modal" data-target="#modalFilter">
                            <i class="fa-solid fa-filter"></i> <?php echo e(__('Filter')); ?>

                        </a>
                        <a href="<?php echo e(route('barang.index')); ?>" class="btn btn-secondary mr-2">
                            <i class="fa-solid fa-arrows-rotate"></i> <?php echo e(__('Refresh')); ?>

                        </a>
                    </form>
                </div>
                <!-- Add New Item Button di kanan -->
                <?php if($hasCreate['buat']): ?>
                    <a href="<?php echo e(route('barang.create')); ?>" class="btn btn-success">
                        <i class="fa-solid fa-plus"></i> <?php echo e(__('Tambah Barang!')); ?>

                    </a>
                <?php endif; ?>
            </div>


            <div class="card-body">
                <div class="table-responsive">
                    <!-- Table -->
                    <table class="table table-bordered table-hover">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col"><?php echo e(__('No')); ?></th>
                                <th scope="col"><?php echo e(__('Kode')); ?></th>
                                <th scope="col"><?php echo e(__('Merek')); ?></th>
                                <th scope="col"><?php echo e(__('Ruang')); ?></th>
                                <th scope="col"><?php echo e(__('Status')); ?></th>
                                <?php if($hasAccess['access'] || $hasDelete['delete']): ?>
                                    <th scope="col"><?php echo e(__('Aksi')); ?></th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td scope="row">
                                        <?php echo e(($barang->currentPage() - 1) * $barang->perPage() + $loop->iteration); ?></td>
                                    <td><?php echo e($bar['kode_barang']); ?></td>
                                    <td><?php echo e($bar['merek_barang']); ?></td>
                                    <td><?php echo e($bar->ruang->nama_ruang ?? __('N/A')); ?></td>
                                    <td
                                        class="
                                                <?php if($bar['status_barang'] == 'Dihapus'): ?> text-danger
                                                <?php elseif($bar['status_barang'] == 'Ada'): ?>
                                                    text-success
                                                <?php elseif($bar['status_barang'] == 'Dipinjam'): ?>
                                                    text-warning
                                                <?php elseif($bar['status_barang'] == 'Dipakai'): ?>
                                                    text-info
                                                <?php elseif($bar['status_barang'] == 'Diperbaiki'): ?>
                                                    text-primary
                                                <?php else: ?>
                                                    text-muted <?php endif; ?>
                                            ">
                                        <?php if($bar['status_barang'] == 'Dihapus'): ?>
                                            <i class="fas fa-trash" aria-hidden="true"></i> <?php echo e($bar['status_barang']); ?>

                                        <?php elseif($bar['status_barang'] == 'Ada'): ?>
                                            <i class="fas fa-check-circle" aria-hidden="true"></i>
                                            <?php echo e($bar['status_barang']); ?>

                                        <?php elseif($bar['status_barang'] == 'Dipinjam'): ?>
                                            <i class="fas fa-hand-paper" aria-hidden="true"></i>
                                            <?php echo e($bar['status_barang']); ?>

                                            <?php if($bar['jumlah'] > 0 ): ?>
                                                <span class="text-warning">Sebagian</span>
                                            <?php endif; ?>
                                        <?php elseif($bar['status_barang'] == 'Dipakai'): ?>
                                            <i class="fas fa-user" aria-hidden="true"></i> <?php echo e($bar['status_barang']); ?>

                                            <?php if($bar['jumlah'] > 0 ): ?>
                                                <span class="text-warning">Sebagian</span>
                                            <?php endif; ?>
                                        <?php elseif($bar['status_barang'] == 'Diperbaiki'): ?>
                                            <i class="fas fa-wrench" aria-hidden="true"></i> <?php echo e($bar['status_barang']); ?>

                                            <?php if($bar['jumlah'] > 0): ?>
                                                <span class="text-warning">Sebagian</span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>


                                    <?php if($hasAccess['access'] || $hasDelete['delete']): ?>
                                        <td style="width: 200px;">
                                            <div class="d-flex">
                                                <!-- Detail Button -->
                                                <?php if($hasAccess['access']): ?>
                                                    <a href="<?php echo e(route('barang.show', $bar['kode_barang'])); ?>"
                                                        class="btn btn-info">
                                                        <i class="fas fa-info-circle"></i> <?php echo e(__('Detil')); ?>

                                                    </a>
                                                <?php endif; ?>
                                                <!-- Tombol Hapus -->
                                                <?php if($hasDelete['delete']): ?>
                                                    <?php if($bar->status_barang === 'Ada'): ?>
                                                        <form action="<?php echo e(route('barang.destroy', $bar->kode_barang)); ?>"
                                                            method="POST" style="display: inline;">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger ml-2"
                                                                onclick="return confirm('Apakah Anda yakin ingin menghapus barang ini?')">
                                                                <i class="fas fa-trash"></i> <?php echo e(__('Hapus!')); ?>

                                                            </button>
                                                        </form>
                                                    <?php else: ?>
                                                        <button type="button" class="btn btn-danger ml-2" disabled>
                                                            <i class="fas fa-trash"></i> <?php echo e(__('Hapus!')); ?>

                                                        </button>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>


        <!-- Pagination and Info -->
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div class="show-info">
                <?php echo e(__('Melihat')); ?> <?php echo e($barang->firstItem()); ?> <?php echo e(__('hingga')); ?> <?php echo e($barang->lastItem()); ?>

                <?php echo e(__('dari total')); ?> <?php echo e($barang->total()); ?> <?php echo e(__('Barang')); ?>

            </div>
            <div class="pagination">
                <?php echo e($barang->links()); ?>

            </div>
        </div>
        <!-- End of Main Content -->
    </div>

    <!-- Modal Filter -->
    <div class="modal fade" id="modalFilter" tabindex="-1" role="dialog" aria-labelledby="modalFilterLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalFilterLabel"><?php echo e(__('Filter Barang')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('barang.index')); ?>" method="GET" class="form-inline">
                        <!-- Filter Kondisi -->
                        <div class="form-group mb-3">
                            <label for="kondisi"><?php echo e(__('Kondisi Barang')); ?></label>
                            <select name="kondisi" class="form-control">
                                <option value=""><?php echo e(__('Filter Kondisi')); ?></option>
                                <?php $__currentLoopData = $kondisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kon->deskripsi_kondisi); ?>"
                                        <?php echo e(request('kondisi') == $kon->deskripsi_kondisi ? 'selected' : ''); ?>>
                                        <?php echo e($kon->deskripsi_kondisi); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Filter Kategori -->
                        <div class="form-group mb-3">
                            <label for="kategori"><?php echo e(__('Kategori Barang')); ?></label>
                            <select name="kategori" class="form-control">
                                <option value=""><?php echo e(__('Filter Kategori')); ?></option>
                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kon->nama_kategori); ?>"
                                        <?php echo e(request('kategori') == $kon->nama_kategori ? 'selected' : ''); ?>>
                                        <?php echo e($kon->nama_kategori); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Filter Harga -->
                        <div class="form-group mb-3">
                            <label for="harga"><?php echo e(__('Harga Barang')); ?></label>
                            <div class="d-flex">
                                <input type="number" name="harga_min" class="form-control"
                                    value="<?php echo e(request('harga_min')); ?>" placeholder="<?php echo e(__('Harga Min')); ?>"
                                    min="0">
                                <span class="mx-2"><?php echo e(__('s/d')); ?></span>
                                <input type="number" name="harga_max" class="form-control"
                                    value="<?php echo e(request('harga_max')); ?>" placeholder="<?php echo e(__('Harga Max')); ?>"
                                    min="0">
                            </div>
                        </div>


                        <!-- Filter Ruang -->
                        <div class="form-group mb-3">
                            <label for="ruang"><?php echo e(__('Ruang Barang')); ?></label>
                            <select name="ruang" class="form-control">
                                <option value=""><?php echo e(__('Filter Ruang')); ?></option>
                                <?php $__currentLoopData = $ruangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kon->nama_ruang); ?>"
                                        <?php echo e(request('ruang') == $kon->nama_ruang ? 'selected' : ''); ?>>
                                        <?php echo e($kon->nama_ruang); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Filter Tahun Perolehan -->
                        <div class="form-group mb-3">
                            <label for="tahun_perolehan"><?php echo e(__('Tahun Perolehan')); ?></label>
                            <div class="d-flex">
                                <input type="number" name="tahun_perolehan_start" class="form-control"
                                    value="<?php echo e(request('tahun_perolehan_start')); ?>" placeholder="<?php echo e(__('Tahun Mulai')); ?>"
                                    min="1900" max="<?php echo e(date('Y')); ?>">
                                <span class="mx-2"><?php echo e(__('s/d')); ?></span>
                                <input type="number" name="tahun_perolehan_end" class="form-control"
                                    value="<?php echo e(request('tahun_perolehan_end')); ?>" placeholder="<?php echo e(__('Tahun Selesai')); ?>"
                                    min="1900" max="<?php echo e(date('Y')); ?>">
                            </div>
                        </div>


                        <!-- Filter Status -->
                        <div class="form-group mb-3">
                            <label for="status"><?php echo e(__('Status Barang')); ?></label>
                            <select name="status" class="form-control">
                                <option value=""><?php echo e(__('Filter Status')); ?></option>
                                <option value="Ada" <?php echo e(request('status') == 'Ada' ? 'selected' : ''); ?>>
                                    <?php echo e(__('Ada')); ?>

                                </option>
                                <option value="Diperbaiki" <?php echo e(request('status') == 'Diperbaiki' ? 'selected' : ''); ?>>
                                    <?php echo e(__('Diperbaiki')); ?>

                                </option>
                                <option value="Dipinjam" <?php echo e(request('status') == 'Dipinjam' ? 'selected' : ''); ?>>
                                    <?php echo e(__('Dipinjam')); ?>

                                </option>
                                <option value="Ditolak" <?php echo e(request('status') == 'Ditolak' ? 'selected' : ''); ?>>
                                    <?php echo e(__('Ditolak')); ?>

                                </option>
                                <option value="Dihapus" <?php echo e(request('status') == 'Dihapus' ? 'selected' : ''); ?>>
                                    <?php echo e(__('Dihapus')); ?>

                                </option>
                            </select>
                        </div>

                        <div class="form-group mb-3">
                            <label for="perolehan"><?php echo e(__('Perolehan Barang')); ?></label>
                            <select name="perolehan" class="form-control">
                                <option value=""><?php echo e(__('Filter Perolehan')); ?></option>
                                <option value="Pembelian" <?php echo e(request('perolehan') == 'Pembelian' ? 'selected' : ''); ?>>
                                    <?php echo e(__('Pembelian')); ?>

                                </option>
                                <option value="Pembuatan" <?php echo e(request('perolehan') == 'Pembuatan' ? 'selected' : ''); ?>>
                                    <?php echo e(__('Pembuatan')); ?>

                                </option>
                                <option value="Persembahan" <?php echo e(request('perolehan') == 'Persembahan' ? 'selected' : ''); ?>>
                                    <?php echo e(__('Persembahan')); ?>

                                </option>
                            </select>
                        </div>

                        <!-- Filter Jumlah -->
                        <div class="form-group mb-3">
                            <label for="jumlah"><?php echo e(__('Jumlah')); ?></label>
                            <div class="d-flex">
                                <input type="number" name="jumlah_min" class="form-control"
                                    value="<?php echo e(request('jumlah_min')); ?>" placeholder="<?php echo e(__('Min Jumlah')); ?>">
                                <input type="number" name="jumlah_max" class="form-control ml-2"
                                    value="<?php echo e(request('jumlah_max')); ?>" placeholder="<?php echo e(__('Max Jumlah')); ?>">
                            </div>
                        </div>

                        <!-- Button Filter -->
                        <button type="submit" class="btn btn-primary"><?php echo e(__('Terapkan Filter')); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startPush('notif'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('warning')): ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <?php echo e(session('warning')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger border-left-danger" role="alert">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\GKJM_INV\resources\views/barang/listbarang.blade.php ENDPATH**/ ?>