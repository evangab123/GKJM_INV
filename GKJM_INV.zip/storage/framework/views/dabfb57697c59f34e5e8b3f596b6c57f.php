<?php $__env->startSection('title', __('Daftar Barang | Inventaris GKJM')); ?>

<?php $__env->startSection('main-content'); ?>
    <?php
        use App\Helpers\PermissionHelper;
        $hasCreate = PermissionHelper::AnyCanCreateBarang();
        $hasEdit = PermissionHelper::AnyCanEditBarang();
        $hasAccess = PermissionHelper::AnyHasAccesstoBarang();
        $hasDelete = PermissionHelper::AnyCanDeleteBarang();
    ?>
    <!-- Main Content goes here -->
    <div class="container-fluid">
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center">
                    
                    <form action="<?php echo e(route('barang.index')); ?>" method="GET" class="form-inline">
                        <input type="text" name="search" class="form-control" placeholder="<?php echo e(__('Cari Barang...')); ?>"
                            value="<?php echo e(request('search')); ?>">
                        <select name="kondisi" class="form-control ml-2">
                            <option value=""><?php echo e(__('Filter Kondisi')); ?></option>
                            <?php $__currentLoopData = $kondisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($kon->deskripsi_kondisi); ?>"
                                    <?php echo e(request('permission') == $kon->deskripsi_kondisi ? 'selected' : ''); ?>>
                                    <?php echo e($kon->deskripsi_kondisi); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <select name="kategori" class="form-control ml-2">
                            <option value=""><?php echo e(__('Filter Kategori')); ?></option>
                            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($kon->nama_kategori); ?>"
                                    <?php echo e(request('permission') == $kon->nama_kategori ? 'selected' : ''); ?>>
                                    <?php echo e($kon->nama_kategori); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <select name="ruang" class="form-control ml-2">
                            <option value=""><?php echo e(__('Filter Ruang')); ?></option>
                            <?php $__currentLoopData = $ruangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($kon->nama_ruang); ?>"
                                    <?php echo e(request('permission') == $kon->nama_ruang ? 'selected' : ''); ?>>
                                    <?php echo e($kon->nama_ruang); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <button type="submit" class="btn btn-primary ml-2"><?php echo e(__('Cari')); ?></button>
                        <a href="<?php echo e(route('barang.index')); ?>" class="btn btn-secondary ml-2">
                            <i class="fa-solid fa-arrows-rotate"></i> <?php echo e(__('Refresh')); ?>

                        </a>
                    </form>
                </div>

                <!-- Add New Item Button di kanan -->
                <?php if($hasCreate['buat']): ?>
                    <a href="<?php echo e(route('barang.create')); ?>" class="btn btn-success">
                        <i class="fa-solid fa-plus"></i> <?php echo e(__('Tambah Barang!')); ?>

                    </a>
                <?php endif; ?>
            </div>


            <div class="card-body">
                <div class="table-responsive">
                    <!-- Table -->
                    <table class="table table-bordered table-hover">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col"><?php echo e(__('No')); ?></th>
                                <th scope="col"><?php echo e(__('Kode')); ?></th>
                                <th scope="col"><?php echo e(__('Merek')); ?></th>
                                <th scope="col"><?php echo e(__('Ruang')); ?></th>
                                <th scope="col"><?php echo e(__('Status')); ?></th>
                                <?php if($hasAccess['access'] || $hasDelete['delete']): ?>
                                    <th scope="col"><?php echo e(__('Aksi')); ?></th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td scope="row">
                                        <?php echo e(($barang->currentPage() - 1) * $barang->perPage() + $loop->iteration); ?></td>
                                    <td><?php echo e($bar['kode_barang']); ?></td>
                                    <td><?php echo e($bar['merek_barang']); ?></td>
                                    <td><?php echo e($bar->ruang->nama_ruang ?? __('N/A')); ?></td>
                                    <td
                                        class="
                                            <?php if($bar['status_barang'] == 'Dihapus'): ?> text-danger
                                            <?php elseif($bar['status_barang'] == 'Ada'): ?>
                                                text-success
                                            <?php elseif($bar['status_barang'] == 'Dipinjam'): ?>
                                                text-warning
                                            <?php elseif($bar['status_barang'] == 'Dipakai'): ?>
                                                text-info
                                            <?php elseif($bar['status_barang'] == 'Diperbaiki'): ?>
                                                text-primary
                                            <?php else: ?>
                                                text-muted <?php endif; ?>">
                                        <?php if($bar['status_barang'] == 'Dihapus'): ?>
                                            <i class="fas fa-trash" aria-hidden="true"></i> <?php echo e($bar['status_barang']); ?>

                                        <?php elseif($bar['status_barang'] == 'Ada'): ?>
                                            <i class="fas fa-check-circle" aria-hidden="true"></i>
                                            <?php echo e($bar['status_barang']); ?>

                                        <?php elseif($bar['status_barang'] == 'Dipinjam'): ?>
                                            <i class="fas fa-user" aria-hidden="true"></i> <?php echo e($bar['status_barang']); ?>

                                        <?php elseif($bar['status_barang'] == 'Dipakai'): ?>
                                            <i class="fas fa-cog" aria-hidden="true"></i> <?php echo e($bar['status_barang']); ?>

                                        <?php elseif($bar['status_barang'] == 'Diperbaiki'): ?>
                                            <i class="fas fa-wrench" aria-hidden="true"></i> <?php echo e($bar['status_barang']); ?>

                                        <?php endif; ?>
                                    </td>
                                    <?php if($hasAccess['access'] || $hasDelete['delete']): ?>
                                        <td style="width: 200px;">
                                            <div class="d-flex">
                                                <!-- Detail Button -->
                                                <?php if($hasAccess['access']): ?>
                                                    <a href="<?php echo e(route('barang.show', $bar['kode_barang'])); ?>"
                                                        class="btn btn-info">
                                                        <i class="fas fa-info-circle"></i> <?php echo e(__('Detil')); ?>

                                                    </a>
                                                <?php endif; ?>
                                                <!-- Tombol Hapus -->
                                                <?php if($hasDelete['delete']): ?>
                                                    <?php if($bar->status_barang === 'Ada'): ?>
                                                        <form action="<?php echo e(route('barang.destroy', $bar->kode_barang)); ?>"
                                                            method="POST" style="display: inline;">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger ml-2"
                                                                onclick="return confirm('Apakah Anda yakin ingin menghapus barang ini?')">
                                                                <i class="fas fa-trash"></i> <?php echo e(__('Hapus!')); ?>

                                                            </button>
                                                        </form>
                                                    <?php else: ?>
                                                        <button type="button" class="btn btn-danger ml-2" disabled>
                                                            <i class="fas fa-trash"></i> <?php echo e(__('Hapus!')); ?>

                                                        </button>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>


        <!-- Pagination and Info -->
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div class="show-info">
                <?php echo e(__('Melihat')); ?> <?php echo e($barang->firstItem()); ?> <?php echo e(__('hingga')); ?> <?php echo e($barang->lastItem()); ?>

                <?php echo e(__('dari total')); ?> <?php echo e($barang->total()); ?> <?php echo e(__('Barang')); ?>

            </div>
            <div class="pagination">
                <?php echo e($barang->links()); ?>

            </div>
        </div>
        <!-- End of Main Content -->
    </div>



<?php $__env->stopSection(); ?>

<?php $__env->startPush('notif'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('warning')): ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <?php echo e(session('warning')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\GKJM_INV\resources\views/barang/listbarang.blade.php ENDPATH**/ ?>