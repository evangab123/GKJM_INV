<?php $__env->startSection('title', __('Daftar Peminjaman | Inventaris GKJM')); ?>

<?php $__env->startSection('main-content'); ?>
    <!-- Modal Peminjaman -->
    <div class="modal fade" id="modalPeminjaman" tabindex="-1" role="dialog" aria-labelledby="modalPeminjamanLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalPeminjamanLabel"><?php echo e(__('Tambah Peminjaman Barang')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('peminjaman.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="kode_barang"><?php echo e(__('Kode Barang')); ?></label>
                            <select class="form-control" id="kode_barang" name="kode_barang" required>
                                <option value=""><?php echo e(__('Pilih Kode Barang')); ?></option>
                                <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->kode_barang); ?>" data-jumlah="<?php echo e($item->jumlah); ?>">
                                    <?php echo e($item->kode_barang); ?> - <?php echo e($item->merek_barang); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="tanggal_peminjaman"><?php echo e(__('Tanggal Peminjaman')); ?></label>
                            <input type="date" class="form-control" id="tanggal_peminjaman" name="tanggal_peminjaman"
                                required>
                        </div>

                        

                        <div class="form-group">
                            <label for="jumlah"><?php echo e(__('Jumlah/Stok')); ?></label>
                            <small id="stok-info" class="text-muted"></small>
                            <input type="number" class="form-control" id="jumlah" name="jumlah" min="0">
                        </div>


                        <div class="form-group">
                            <label for="keterangan"><?php echo e(__('Keterangan')); ?></label>
                            <small id="keterangan" class="text-muted"><?php echo e(__("Isikan Nama atau infomasi yang sesuai")); ?></small>
                            <textarea class="form-control" id="keterangan" name="keterangan" rows="3"></textarea>
                        </div>

                        

                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Tutup')); ?></button>
                        <button type="submit" class="btn btn-success"><?php echo e(__('Simpan')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- End Modal Peminjaman -->

    <div class="container-fluid">

        <?php if(session('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>

        <div class="card shadow mb-4">
            <div class="card-header pt-3 d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center">
                    
                    <form action="<?php echo e(route('peminjaman.index')); ?>" method="GET" class="form-inline">
                        <input type="text" name="search" class="form-control mr-2 ml-2"
                            placeholder="<?php echo e(__('Cari ...')); ?>" value="<?php echo e(request('search')); ?>" style="max-width: 200px;"
                            oninput="this.form.submit()">
                        <!-- Filter Tanggal Peminjaman -->
                        <label for="tanggal_peminjaman"><?php echo e(__('Tanggal Peminjaman:')); ?></label>
                        <input type="date" name="tanggal_peminjaman" class="form-control mr-2 ml-2"
                            value="<?php echo e(request('tanggal_peminjaman')); ?>" placeholder="<?php echo e(__('Tanggal Peminjaman')); ?>"
                            style="max-width: 150px;" onchange="this.form.submit()">
                        <!-- Filter Tanggal Selesai -->
                        <label for="tanggal_pengembalian"><?php echo e(__('Tanggal Pengembalian:')); ?></label>
                        <input type="date" name="tanggal_pengembalian" class="form-control mr-2 ml-2"
                            value="<?php echo e(request('tanggal_pengembalian')); ?>" placeholder="<?php echo e(__('Tanggal Pengembalian')); ?>"
                            style="max-width: 150px;" onchange="this.form.submit()">
                        <!-- Filter Status -->
                        <label for="status"><?php echo e(__('Status Barang')); ?></label>
                        <select name="status" class="form-control" onchange="this.form.submit()">
                            <option value=""><?php echo e(__('Filter Status')); ?></option>
                            <option value="Dipinjam" <?php echo e(request('status') == 'Dipinjam' ? 'selected' : ''); ?>>
                                <?php echo e(__('Dipinjam')); ?>

                            </option>
                            <option value="Dikembalikan" <?php echo e(request('status') == 'Dikembalikan' ? 'selected' : ''); ?>>
                                <?php echo e(__('Dikembalikan')); ?>

                            </option>
                        </select>
                        <!-- Refresh-->
                        <a href="<?php echo e(route('peminjaman.index')); ?>" class="btn btn-secondary ml-2 mr-2">
                            <i class="fa-solid fa-arrows-rotate"></i> <?php echo e(__('Refresh')); ?>

                        </a>
                    </form>
                </div>
                <a href="#" class="btn btn-success" data-toggle="modal" data-target="#modalPeminjaman">
                    <i class="fa-solid fa-plus"></i> <?php echo e(__('Buat Peminjaman Barang!')); ?>

                </a>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col"><?php echo e(__('No')); ?></th>
                                <th scope="col"><?php echo e(__('Kode Barang')); ?></th>
                                <th scope="col"><?php echo e(__('Merek Barang')); ?></th>
                                <th scope="col"><?php echo e(__('Jumlah')); ?></th>
                                <th scope="col"><?php echo e(__('Pengguna Akun')); ?></th>
                                <th scope="col"><?php echo e(__('Tanggal Peminjaman')); ?></th>
                                <th scope="col"><?php echo e(__('Tanggal Pengembalian')); ?></th>
                                <th scope="col"><?php echo e(__('Keterangan')); ?></th>
                                <th scope="col"><?php echo e(__('Status Peminjaman')); ?></th>
                                <th scope="col"><?php echo e(__('Aksi')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td scope="row">
                                        <?php echo e(($data->currentPage() - 1) * $data->perPage() + $loop->iteration); ?>

                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('barang.show', $item->kode_barang)); ?>">
                                            <?php echo e($item->kode_barang ?? '-'); ?>

                                        </a>
                                    </td>
                                    <td><?php echo e($item->barang->merek_barang ?? 'Tidak tersedia'); ?></td>
                                    <td><?php echo e($item->jumlah); ?></td>
                                    <td><?php echo e($item->pengguna->nama_pengguna ?? 'Tidak tersedia'); ?></td>
                                    <td><?php echo e($item->tanggal_peminjaman); ?></td>
                                    <td><?php echo e($item->tanggal_pengembalian ?? 'Belum dikembalikan/Masih dipinjam'); ?></td>
                                    <td><?php echo e($item->keterangan); ?></td>
                                    <td
                                        class="
                                    <?php if($item->status_peminjaman == 'Dipinjam'): ?> text-warning
                                    <?php elseif($item->status_peminjaman == 'Dikembalikan'): ?> text-success
                                    <?php else: ?> text-muted <?php endif; ?>">
                                        <?php if($item->status_peminjaman == 'Dipinjam'): ?>
                                            <i class="fas fa-hand-paper" style="color: #f39c12;" title="Dipinjam"></i>
                                            <?php echo e(__('Dipinjam')); ?>

                                        <?php elseif($item->status_peminjaman == 'Dikembalikan'): ?>
                                            <i class="fas fa-undo" style="color: #28a745;" title="Dikembalikan"></i>
                                            <?php echo e(__('Dikembalikan')); ?>

                                        <?php else: ?>
                                            <i class="fas fa-question-circle" style="color: #6c757d;"
                                                title="Status Tidak Diketahui"></i>
                                            <?php echo e(__('Status Tidak Diketahui')); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td style="width:120px">
                                        <div class="d-flex">
                                            <form action="<?php echo e(route('peminjaman.kembalikan', $item->peminjaman_id)); ?>"
                                                method="POST">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-primary"
                                                    onclick="return confirm('<?php echo e(__('Apakah Anda yakin pengguna telah kembalikan peminjaman ini?')); ?>')"
                                                    <?php if($item->status_peminjaman != 'Dipinjam'): ?> disabled <?php endif; ?>>
                                                    <i class="fas fa-undo"></i> <?php echo e(__('Selesai')); ?>

                                                </button>
                                            </form>
                                            <form action="<?php echo e(route('peminjaman.destroy', $item->peminjaman_id)); ?>"
                                                method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button type="submit" class="btn btn-danger"
                                                    onclick="return confirm('<?php echo e(__('Are you sure to delete this record?')); ?>')"
                                                    <?php if($item->status_peminjaman != 'Dipinjam'): ?> disabled <?php endif; ?>>
                                                    <i class="fas fa-trash"></i> <?php echo e(__('Hapus')); ?>

                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- Pagination and Info -->
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div class="show-info">
                <?php echo e(__('Melihat')); ?> <?php echo e($data->firstItem()); ?> <?php echo e(__('hingga')); ?> <?php echo e($data->lastItem()); ?>

                <?php echo e(__('dari total')); ?> <?php echo e($data->total()); ?> <?php echo e(__('Peminjamanan Barang')); ?>

            </div>
            <div class="pagination">
                <?php echo e($data->links()); ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('notif'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('warning')): ?>
        <div class="alert alert-warning border-left-warning alert-dismissible fade show" role="alert">
            <?php echo e(session('warning')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const kodeBarangSelect = document.getElementById('kode_barang');
        const jumlahInput = document.getElementById('jumlah');
        const stokInfo = document.getElementById('stok-info');

        // Fungsi untuk update jumlah yang tersedia
        kodeBarangSelect.addEventListener('change', function() {
            const selectedOption = kodeBarangSelect.options[kodeBarangSelect.selectedIndex];
            const availableStock = selectedOption.getAttribute('data-jumlah');

            // Update informasi stok yang tersedia
            stokInfo.textContent = `Stok tersedia: ${availableStock}`;

            jumlahInput.setAttribute('max', availableStock);
            jumlahInput.setAttribute('min', 0);

            jumlahInput.value = 0;
        });

        // Trigger change event on load to set the initial stock
        kodeBarangSelect.dispatchEvent(new Event('change'));
    });
</script>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\GKJM_INV\resources\views/peminjaman/list.blade.php ENDPATH**/ ?>