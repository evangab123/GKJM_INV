<?php $__env->startSection('title', 'Detail Barang | Inventaris GKJM'); ?>

<?php $__env->startSection('main-content'); ?>
    <?php
        use App\Helpers\PermissionHelper;
        $hasCreate = PermissionHelper::AnyCanCreateBarang();
        $hasEdit = PermissionHelper::AnyCanEditBarang();
        $hasAccess = PermissionHelper::AnyHasAccesstoBarang();
        $hasDelete = PermissionHelper::AnyCanDeleteBarang();
    ?>
    <!-- Main Content -->
    <?php if(session('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?>
    <div class="row mb-3">

        <!-- Button Kembali -->
        <div>
            <!-- Tombol Kembali -->
            <a href="<?php echo e(route('barang.index')); ?>" class="btn btn-secondary">
                <i class="fa-solid fa-arrow-left"></i> <?php echo e(__('Kembali')); ?>

            </a>

            <!-- Button Edit/Close -->
            <?php if($isEditing): ?>
                <!-- Tombol Tutup (keluar dari mode edit) -->
                <a href="<?php echo e(route('barang.show', $barang->kode_barang)); ?>" class="btn btn-secondary ml-2">
                    <i class="fa-solid fa-times"></i> <?php echo e(__('Tutup')); ?>

                </a>
            <?php else: ?>
                <!-- Tombol Edit -->
                <?php if($hasEdit['edit']): ?>
                    <a href="<?php echo e(route('barang.edit', $barang->kode_barang)); ?>" class="btn btn-primary ml-2">
                        <i class="fa-solid fa-pen-to-square"></i> <?php echo e(__('Edit')); ?>

                    </a>
                <?php endif; ?>
            <?php endif; ?>

            <!-- Tombol Lihat Keterangan -->
            <?php if($hasAccess['access']): ?>
                <a href="<?php echo e(route('barang.keterangan', $barang->kode_barang)); ?>" class="btn btn-info ml-2">
                    <?php echo e(__('Lihat Keterangan')); ?>

                </a>
            <?php endif; ?>

            <!-- Tombol Hapus -->
            <?php if($hasDelete['delete']): ?>
                <?php if($barang->status_barang === 'Ada'): ?>
                    <button type="button" class="btn btn-danger ml-2"
                        onclick="openDeleteModal('<?php echo e($barang['kode_barang']); ?>', '<?php echo e($barang['merek_barang']); ?>')">
                        <i class="fas fa-trash"></i> <?php echo e(__('Penghapusan Barang!')); ?>

                    </button>
                <?php else: ?>
                    <button type="button" class="btn btn-danger ml-2" disabled>
                        <i class="fas fa-trash"></i> <?php echo e(__('Penghapusan Barang!')); ?>

                    </button>
                <?php endif; ?>
            <?php endif; ?>


            <!-- Tombol Kunci atau Lepas Kunci -->
            <?php if(auth()->user()->hasRole('Super Admin||Majelis')): ?>
                <?php if($barangTerkunci): ?>
                    <form action="<?php echo e(route('terkunci.destroy', $barangTerkunci->kode_barang)); ?>" method="POST"
                        class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger ml-2"
                            onclick="return confirm('Apakah Anda yakin ingin melepas kunci barang ini?')">
                            <i class='fas fa-lock'></i> <?php echo e(__('Lepas Kunci')); ?>

                        </button>
                    </form>
                <?php else: ?>
                    <!-- Tombol Kunci Barang -->
                    <button type="button" class="btn btn-warning ml-2" data-toggle="modal" data-target="#addModal">
                        <i class="fas fa-lock-open"></i> <?php echo e(__('Kunci Barang')); ?>

                    </button>
                <?php endif; ?>
            <?php endif; ?>
        </div>

    </div>

    <div class="row">
        <!-- Foto Barang -->
        <div class="col-md-4">
            <div class="card h-100">
                <!-- Foto Barang -->
                <img src="<?php echo e(asset('img/barang/' . $barang->path_gambar)); ?>" class="card-img-top img-fluid w-100 mb-3"
                    alt="Foto Barang" style="object-fit: cover; height: 300px;">


                <!-- QR Code -->
                


                <div class="card-body text-center">
                    <h5 class="card-title"><?php echo e($barang->nama_barang); ?></h5>
                </div>
            </div>
        </div>


        <!-- Detail Barang -->
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title"><?php echo e(__('Detail Barang')); ?></h5>
                    <div class="card-body">
                        <?php if($isEditing): ?>
                            <!-- Form Edit -->
                            <form action="<?php echo e(route('barang.update_detail', $barang->kode_barang)); ?>" method="POST"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <table class="table">
                                    <tbody>
                                        <tr>
                                            <th><?php echo e(__('Kode')); ?></th>
                                            <td><input type="text" class="form-control" name="kode_barang"
                                                    value="<?php echo e($barang->kode_barang); ?>" readonly></td>
                                        </tr>
                                        <tr>
                                            <th><?php echo e(__('Merek')); ?></th>
                                            <td><input type="text" class="form-control" name="merek_barang"
                                                    value="<?php echo e($barang->merek_barang); ?>"></td>
                                        </tr>
                                        <tr>
                                            <th><?php echo e(__('Perolehan')); ?></th>
                                            <td>
                                                <select class="form-control" id="perolehan_barang" name="perolehan_barang">
                                                    <option value="Hibah"
                                                        <?php echo e($barang['perolehan_barang'] == 'Hibah' ? 'selected' : ''); ?>>
                                                        <?php echo e(__('Hibah')); ?>

                                                    </option>
                                                    <option value="Pembelian"
                                                        <?php echo e($barang['perolehan_barang'] == 'Pembelian' ? 'selected' : ''); ?>>
                                                        <?php echo e(__('Pembelian')); ?>

                                                    </option>
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th><?php echo e(__('Harga Beli')); ?></th>
                                            <td>
                                                <input type="text" class="form-control" name="harga_pembelian"
                                                    value="<?php echo e($barang->harga_pembelian); ?>"
                                                    onchange="calculateNilaiEkonomis()">
                                            </td>
                                        </tr>
                                        <tr>
                                            <th><?php echo e(__('Tahun Beli')); ?></th>
                                            <td>
                                                <input type="text" class="form-control" name="tahun_pembelian"
                                                    value="<?php echo e($barang->tahun_pembelian); ?>"
                                                    onchange="calculateNilaiEkonomis()">
                                            </td>
                                        </tr>
                                        <tr>
                                            <th><?php echo e(__('Nilai Ekonomis')); ?></th>
                                            <td>
                                                <input type="text" class="form-control" name="nilai_ekonomis_barang"
                                                    value="<?php echo e($barang->nilai_ekonomis_barang); ?>" readonly>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th><?php echo e(__('Jumlah/Stok')); ?></th>
                                            <td>
                                                <input type="text" class="form-control" name="jumlah"
                                                    value="<?php echo e($barang->jumlah); ?>">
                                            </td>
                                        </tr>
                                        <tr>
                                            <th><?php echo e(__('Keterangan')); ?></th>
                                            <td>
                                                <input type="text" class="form-control" name="keterangan"
                                                    value="<?php echo e($barang->keterangan); ?>">
                                            </td>
                                        </tr>
                                        <tr>
                                            <th><?php echo e(__('Ruang')); ?></th>
                                            <td>
                                                <select class="form-control" name="ruang_id">
                                                    <?php $__currentLoopData = $ruang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rua): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($rua->ruang_id); ?>"
                                                            <?php echo e($rua->ruang_id == $barang->ruang_id ? 'selected' : ''); ?>>
                                                            <?php echo e($rua->nama_ruang); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th><?php echo e(__('Kondisi')); ?></th>
                                            <td>
                                                <select class="form-control" name="kondisi_id">
                                                    <?php $__currentLoopData = $kondisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($kon->kondisi_id); ?>"
                                                            <?php echo e($kon->kondisi_id == $barang->kondisi_id ? 'selected' : ''); ?>>
                                                            <?php echo e($kon->deskripsi_kondisi); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th><?php echo e(__('Kategori')); ?></th>
                                            <td>
                                                <select class="form-control" name="kategori_barang_id">
                                                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($kat->kategori_barang_id); ?>"
                                                            <?php echo e($kat->kategori_barang_id == $barang->kategori_barang_id ? 'selected' : ''); ?>>
                                                            <?php echo e($kat->nama_kategori); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                        </tr>

                                        <tr>
                                            <th><?php echo e(__('Status')); ?></th>
                                            <td>
                                                <select class="form-control" name="status_barang">
                                                    <option value="Ada"
                                                        <?php echo e($barang->status_barang == 'Ada' ? 'selected' : ''); ?>>
                                                        <?php echo e(__('Ada')); ?>

                                                    </option>
                                                    
                                                    <option value="Diperbaiki"
                                                        <?php echo e($barang->status_barang == 'Diperbaiki' ? 'selected' : ''); ?>>
                                                        <?php echo e(__('Diperbaiki')); ?>

                                                    </option>
                                                    
                                                    </option>
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th><?php echo e(__('Foto Barang')); ?></th>
                                            <td>
                                                <input type="file" class="form-control" name="path_gambar"
                                                    accept="image/*">
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <button type="submit" class="btn btn-primary"><?php echo e(__('Perbarui')); ?></button>
                            </form>
                        <?php else: ?>
                            <!-- Detail Barang -->
                            <table class="table">
                                <tbody>
                                    <tr>
                                        <th><?php echo e(__('Kode')); ?></th>
                                        <td><?php echo e($barang->kode_barang); ?></td>
                                    </tr>
                                    <tr>
                                        <th><?php echo e(__('Merek')); ?></th>
                                        <td><?php echo e($barang->merek_barang); ?></td>
                                    </tr>
                                    <tr>
                                        <th><?php echo e(__('Perolehan')); ?></th>
                                        <td><?php echo e($barang->perolehan_barang); ?></td>
                                    </tr>
                                    <tr>
                                        <th><?php echo e(__('Harga Beli')); ?></th>
                                        <td>Rp <?php echo e(number_format($barang->harga_pembelian, 2, ',', '.')); ?></td>
                                    </tr>
                                    <tr>
                                        <th><?php echo e(__('Tahun Beli')); ?></th>
                                        <td><?php echo e($barang->tahun_pembelian); ?></td>
                                    </tr>
                                    <tr>
                                        <th><?php echo e(__('Nilai Ekonomis')); ?></th>
                                        <td>Rp <?php echo e(number_format($barang->nilai_ekonomis_barang, 2, ',', '.')); ?></td>
                                    </tr>
                                    <tr>
                                        <th><?php echo e(__('Jumlah/Stok')); ?></th>
                                        <td><?php echo e($barang->jumlah); ?></td>
                                    </tr>
                                    <tr>
                                        <th><?php echo e(__('Keterangan')); ?></th>
                                        <td><?php echo e($barang->keterangan); ?></td>
                                    </tr>
                                    <tr>
                                        <th><?php echo e(__('Ruang')); ?></th>
                                        <td><?php echo e($barang->ruang->nama_ruang); ?></td>
                                    </tr>
                                    <tr>
                                        <th><?php echo e(__('Kondisi')); ?></th>
                                        <td><?php echo e($barang->kondisi->deskripsi_kondisi); ?></td>
                                    </tr>
                                    <tr>
                                        <th><?php echo e(__('Kategori')); ?></th>
                                        <td><?php echo e($barang->kategori->nama_kategori); ?></td>
                                    </tr>
                                    <tr>
                                        <th><?php echo e(__('Status')); ?></th>
                                        <td><?php echo e($barang->status_barang); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal Hapus -->
        <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLabel"><?php echo e(__('Konfirmasi Penghapusan')); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <?php echo e(__('Apakah Anda yakin ingin melakukan penghapusan barang?')); ?>


                        <div class="mb-3">
                            <label for="alasan" class="form-label"><?php echo e(__('Alasan Penghapusan:')); ?></label>
                            <input type="text" class="form-control" id="alasan" name="alasan" required>
                        </div>

                        <div class="mb-3">
                            <label for="tanggal_penghapusan" class="form-label"><?php echo e(__('Tanggal Penghapusan:')); ?></label>
                            <input type="date" class="form-control" id="tanggal_penghapusan"
                                name="tanggal_penghapusan" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary"
                            data-dismiss="modal"><?php echo e(__('Batal')); ?></button>
                        <form action="" method="POST" class="d-inline" id="deleteForm">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="alasan" id="hiddenAlasan">
                            <input type="hidden" name="kode_barang" id="hiddenKodeBarang">
                            <input type="hidden" name="tanggal_penghapusan" id="hiddenTanggalPenghapusan">
                            <button type="button" class="btn btn-danger"
                                onclick="submitDeleteForm()"><?php echo e(__('Hapuskan!')); ?></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal Kunci -->
        <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <form action="<?php echo e(route('terkunci.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="modal-header">
                            <h5 class="modal-title" id="addModalLabel"><?php echo e(__('Tambah Barang Terkunci')); ?></h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <!-- Input Hidden untuk Kode Barang -->
                            <input type="hidden" id="hidden_kode_barang" name="kode_barang"
                                value="<?php echo e($barang->kode_barang); ?>">

                            <div class="form-group">
                                <label for="alasan_terkunci"><?php echo e(__('Alasan Terkunci')); ?></label>
                                <textarea class="form-control" id="alasan_terkunci" name="alasan_terkunci" required></textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary"
                                data-dismiss="modal"><?php echo e(__('Tutup')); ?></button>
                            <button type="submit" class="btn btn-primary"><?php echo e(__('Simpan')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- End of Main Content -->
    <?php $__env->stopSection(); ?>

    <?php $__env->startPush('notif'); ?>
        <?php if(session('success')): ?>
            <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <?php if(session('status')): ?>
            <div class="alert alert-success border-left-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
    <?php $__env->stopPush(); ?>
    <script>
        function calculateNilaiEkonomis() {

            const hargaPembelianInput = document.querySelector('input[name="harga_pembelian"]');
            const tahunPembelianInput = document.querySelector('input[name="tahun_pembelian"]');
            const nilaiEkonomisInput = document.querySelector('input[name="nilai_ekonomis_barang"]');

            const hargaPembelian = parseFloat(hargaPembelianInput.value) || 0;
            const tahunPembelian = parseFloat(tahunPembelianInput.value) || new Date().getFullYear();


            const umurEkonomis = 10;
            const nilaiSisa = 100;


            const totalDepreciation = (hargaPembelian - nilaiSisa) / umurEkonomis;

            const currentYear = new Date().getFullYear();
            const yearsUsed = currentYear - tahunPembelian;


            let nilaiEkonomis = hargaPembelian - (totalDepreciation * yearsUsed);

            nilaiEkonomis = nilaiEkonomis >= 0 ? nilaiEkonomis : 0;

            nilaiEkonomisInput.value = nilaiEkonomis.toFixed(2);
        }
    </script>
    <script>
        function openDeleteModal(kode_barang, merek_barang) {
            $('#hiddenKodeBarang').val(kode_barang);
            $('#deleteModal').modal('show');
        }

        function submitDeleteForm() {
            const alasan = $('#alasan').val();
            const tanggalPenghapusan = $('#tanggal_penghapusan').val();
            const kodeBarang = $('#hiddenKodeBarang').val();

            $('#hiddenAlasan').val(alasan);
            $('#hiddenTanggalPenghapusan').val(tanggalPenghapusan);

            $('#deleteForm').attr('action', '<?php echo e(route('barang.penghapusanbarang', ':kode_barang')); ?>'.replace(
                ':kode_barang', kodeBarang));

            $('#deleteForm').submit();
        }
    </script>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\GKJM_INV\resources\views/barang/detailbarang.blade.php ENDPATH**/ ?>