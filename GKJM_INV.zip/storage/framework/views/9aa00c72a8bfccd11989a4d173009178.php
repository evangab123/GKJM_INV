<?php $__env->startSection('title', __('Daftar Penghapusan | Inventaris GKJM')); ?>

<?php $__env->startSection('main-content'); ?>
    <?php
        use App\Helpers\PermissionHelper;
        $hasAccess = PermissionHelper::AnyCanAccessPenghapusan();
        $hasDelete = PermissionHelper::AnyCanDeletePenghapusan();
    ?>

    <div class="container-fluid">

        <?php if(session('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>

        <div class="card shadow mb-4">
            <div class="card-header pt-3 d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center">
                    
                    <form action="<?php echo e(route('penghapusan.index')); ?>" method="GET" class="form-inline">
                        <input type="text" name="search" class="form-control" placeholder="<?php echo e(__('Cari ...')); ?>"
                            value="<?php echo e(request('search')); ?>" style="max-width: 200px;" oninput="this.form.submit()">

                        <a href="<?php echo e(route('penghapusan.index')); ?>" class="btn btn-secondary ml-2">
                            <i class="fa-solid fa-arrows-rotate"></i> <?php echo e(__('Refresh')); ?>

                        </a>
                    </form>
                </div>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col"><?php echo e(__('No')); ?></th>
                                <th scope="col"><?php echo e(__('Kode Barang')); ?></th>
                                <th scope="col"><?php echo e(__('Tanggal Penghapusan')); ?></th>
                                <th scope="col"><?php echo e(__('Alasan Penghapusan')); ?></th>
                                <th scope="col"><?php echo e(__('Nilai Sisa')); ?></th>
                                <?php if($hasDelete['delete']): ?>
                                    <th scope="col"><?php echo e(__('Aksi')); ?></th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $penghapusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td scope="row">
                                        <?php echo e(($penghapusan->currentPage() - 1) * $penghapusan->perPage() + $loop->iteration); ?>

                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('barang.show', $item->kode_barang)); ?>">
                                            <?php echo e($item->kode_barang ?? '-'); ?>

                                        </a>
                                    </td>
                                    <td><?php echo e($item->tanggal_penghapusan); ?></td>
                                    <td><?php echo e($item->alasan_penghapusan); ?></td>
                                    <td><?php echo e(number_format($item->nilai_sisa, 2)); ?></td>
                                    <?php if($hasDelete['delete']): ?>
                                        <td style="width: 200px;">
                                            <form action="<?php echo e(route('penghapusan.destroy', $item->penghapusan_id)); ?>"
                                                method="POST" style="display:inline;"
                                                onsubmit="return confirm('<?php echo e(__('Apakah Anda yakin ingin menghapus?')); ?>');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>

                                                <?php
                                                    $dateDiff = \Carbon\Carbon::parse($item->tanggal_penghapusan)->diffInDays(
                                                        now(),
                                                    );
                                                ?>

                                                <button type="submit" class="btn btn-danger"
                                                    <?php echo e($dateDiff > (int) env('DELETE_PERIOD_DAYS', 7) ? 'disabled' : ''); ?>>
                                                    <i class="fas fa-trash"></i> <?php echo e(__(' Hapus!')); ?>

                                                </button>

                                            </form>
                                        </td>
                                    <?php endif; ?>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <?php echo e($penghapusan->links()); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('notif'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('warning')): ?>
        <div class="alert alert-warning border-left-warning alert-dismissible fade show" role="alert">
            <?php echo e(session('warning')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\GKJM_INV\resources\views/penghapusan/list.blade.php ENDPATH**/ ?>